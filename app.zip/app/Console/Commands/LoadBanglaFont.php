<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Dompdf\Dompdf;
use Dompdf\Options;

class LoadBanglaFont extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'font:load-bangla {font?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Load Bangla font (Kalpurush or SolaimanLipi) into DomPDF';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $fontName = $this->argument('font') ?? 'kalpurush';
        
        $fontFile = storage_path("fonts/{$fontName}.ttf");
        
        if (!file_exists($fontFile)) {
            $this->error("Font file not found: {$fontFile}");
            $this->info("Please download the font and place it in storage/fonts/");
            return 1;
        }
        
        $this->info("Loading font: {$fontName}");
        
        // Copy font to DomPDF font directory
        $options = new Options();
        $fontDir = storage_path('fonts');
        $dompdfFontDir = $fontDir;
        
        $targetFile = $dompdfFontDir . '/' . strtolower($fontName) . '.ttf';
        
        if (copy($fontFile, $targetFile)) {
            $this->info("Font copied to: {$targetFile}");
        } else {
            $this->error("Failed to copy font file");
            return 1;
        }
        
        $this->info("Font loaded successfully!");
        $this->info("You can now use '{$fontName}' as the font-family in your PDF views.");
        
        return 0;
    }
}
